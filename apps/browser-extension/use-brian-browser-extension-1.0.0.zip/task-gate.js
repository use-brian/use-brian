/**
 * Per-task consent, tab-scope enforcement, and persistent Stop.
 *
 * The server supplies the Browser profile's control mode on every command.
 * The extension keeps raw Chrome tab ids private and exposes only task-local
 * opaque handles to the model-facing tool surface.
 */
import { RESTRICTED_TAB_MESSAGE } from './tab-eligibility.js';
export const CONSENT_IDLE_RESET_MS = 10 * 60 * 1000;
export const CONSENT_PROMPT_TIMEOUT_MS = 60_000;
export const MAX_TASK_CREATED_TABS = 8;
const DENIAL_ERRORS = {
    denied: {
        code: 'consent_denied',
        message: 'The user declined to let Use Brian act in this tab.',
    },
    restricted_url: { code: 'no_eligible_tab', message: RESTRICTED_TAB_MESSAGE },
    no_active_tab: {
        code: 'no_eligible_tab',
        message: 'No web page is open in the browser. Ask the user to open the site they want Use Brian to work on, then try again.',
    },
};
function tabScopeError() {
    return Object.assign(new Error('That tab is outside this browser profile\'s allowed task scope.'), {
        code: 'tab_not_allowed',
    });
}
export class TaskGate {
    tabs = new Map();
    handleByTab = new Map();
    activeHandle = null;
    nextHandle = 1;
    mode = 'task_tabs';
    stopped = false;
    manualApprovalRequired = false;
    stopGeneration = 0;
    lastCommandAt = 0;
    promptInFlight = null;
    promptStopGeneration = 0;
    prompt;
    now;
    constructor(opts) {
        this.prompt = opts.prompt;
        this.now = opts.now ?? Date.now;
    }
    /** Resolve the currently selected tab, prompting once when consent is stale. */
    async requireTab(mode = 'task_tabs') {
        this.setMode(mode);
        const now = this.now();
        const current = this.currentEntry();
        if (!this.stopped && current && now - this.lastCommandAt <= CONSENT_IDLE_RESET_MS) {
            this.lastCommandAt = now;
            return current.tabId;
        }
        // Keep task-created tabs registered for later Stop cleanup. They are not
        // usable while no tab is selected; a fresh Allow reactivates the task.
        this.clearAuthorization(true);
        if (!this.promptInFlight) {
            this.promptStopGeneration = this.stopGeneration;
            this.promptInFlight = this.prompt({
                allowPreApproval: !this.stopped && !this.manualApprovalRequired,
            }).finally(() => {
                this.promptInFlight = null;
            });
        }
        const stopGeneration = this.promptStopGeneration;
        const outcome = await this.promptInFlight;
        if (!outcome.allowed) {
            const { code, message } = DENIAL_ERRORS[outcome.reason];
            throw Object.assign(new Error(message), { code });
        }
        if (this.stopGeneration !== stopGeneration) {
            throw Object.assign(new Error('The task stopped while browser permission was pending.'), {
                code: 'stopped',
            });
        }
        this.stopped = false;
        this.manualApprovalRequired = false;
        const existing = this.entryForTab(outcome.tabId);
        if (existing)
            this.activeHandle = existing.handle;
        else
            this.register(outcome.tabId, 'approved', true);
        this.lastCommandAt = this.now();
        return outcome.tabId;
    }
    /** Apply a newly resolved server policy. Narrowing immediately drops full-scope tabs. */
    setMode(mode) {
        this.mode = mode;
        if (mode === 'full_browser')
            return;
        for (const entry of [...this.tabs.values()]) {
            if (entry.origin === 'full')
                this.removeEntry(entry);
        }
        if (!this.currentEntry()) {
            this.activeHandle = this.firstAllowedHandle();
        }
    }
    registerCreatedTab(tabId, makeActive = true) {
        const existing = this.entryForTab(tabId);
        if (existing) {
            if (makeActive)
                this.activeHandle = existing.handle;
            return existing.handle;
        }
        if (this.createdTabIds().length >= MAX_TASK_CREATED_TABS) {
            throw Object.assign(new Error(`A task may open at most ${MAX_TASK_CREATED_TABS} browser tabs.`), { code: 'tab_limit' });
        }
        return this.register(tabId, 'created', makeActive).handle;
    }
    /** Register an eligible pre-existing tab found while full-profile mode is active. */
    registerFullTab(tabId) {
        const existing = this.entryForTab(tabId);
        if (existing)
            return existing.handle;
        if (this.mode !== 'full_browser')
            throw tabScopeError();
        return this.register(tabId, 'full', false).handle;
    }
    selectHandle(handle, mode = this.mode) {
        this.setMode(mode);
        const entry = this.tabs.get(handle);
        if (!entry || (mode === 'task_tabs' && entry.origin === 'full'))
            throw tabScopeError();
        this.activeHandle = handle;
        this.lastCommandAt = this.now();
        return entry.tabId;
    }
    handleForTab(tabId) {
        return this.handleByTab.get(tabId) ?? null;
    }
    entries(mode = this.mode) {
        this.setMode(mode);
        return [...this.tabs.values()].filter((entry) => mode === 'full_browser' || entry.origin !== 'full');
    }
    isAuthorizedTab(tabId) {
        return !this.stopped && this.activeHandle != null && this.handleByTab.has(tabId);
    }
    isTaskOwnedTab(tabId) {
        const entry = this.entryForTab(tabId);
        return Boolean(entry && entry.origin !== 'full');
    }
    canOpenTaskTab() {
        return this.createdTabIds().length < MAX_TASK_CREATED_TABS;
    }
    /** Drop consent without latching Stop, so the next command asks again. */
    revokeConsent(options = {}) {
        this.clearAuthorization(true);
        this.lastCommandAt = 0;
        if (options.requireManualApproval)
            this.manualApprovalRequired = true;
    }
    /** Persistent Stop. Returns only task-created tabs for caller-side cleanup. */
    stop() {
        const created = this.createdTabIds();
        this.stopGeneration += 1;
        this.stopped = true;
        this.clearAuthorization(false);
        return created;
    }
    /** Tab housekeeping. Returns true when the closed tab was selected. */
    onTabRemoved(tabId) {
        const entry = this.entryForTab(tabId);
        if (!entry)
            return false;
        const wasCurrent = this.activeHandle === entry.handle;
        this.removeEntry(entry);
        if (wasCurrent)
            this.activeHandle = this.firstAllowedHandle();
        return wasCurrent;
    }
    currentTab() {
        return this.currentEntry()?.tabId ?? null;
    }
    currentHandle() {
        return this.currentEntry()?.handle ?? null;
    }
    isStopped() {
        return this.stopped;
    }
    register(tabId, origin, makeActive) {
        const entry = { handle: `tab-${this.nextHandle++}`, tabId, origin };
        this.tabs.set(entry.handle, entry);
        this.handleByTab.set(tabId, entry.handle);
        if (makeActive)
            this.activeHandle = entry.handle;
        return entry;
    }
    entryForTab(tabId) {
        const handle = this.handleByTab.get(tabId);
        return handle ? this.tabs.get(handle) ?? null : null;
    }
    currentEntry() {
        return this.activeHandle ? this.tabs.get(this.activeHandle) ?? null : null;
    }
    firstAllowedHandle() {
        for (const entry of this.tabs.values()) {
            if (this.mode === 'full_browser' || entry.origin !== 'full')
                return entry.handle;
        }
        return null;
    }
    createdTabIds() {
        return [...this.tabs.values()]
            .filter((entry) => entry.origin === 'created')
            .map((entry) => entry.tabId);
    }
    removeEntry(entry) {
        this.tabs.delete(entry.handle);
        this.handleByTab.delete(entry.tabId);
        if (this.activeHandle === entry.handle)
            this.activeHandle = null;
    }
    clearAuthorization(preserveCreated) {
        if (preserveCreated) {
            for (const entry of [...this.tabs.values()]) {
                if (entry.origin !== 'created')
                    this.removeEntry(entry);
            }
        }
        else {
            this.tabs.clear();
            this.handleByTab.clear();
        }
        this.activeHandle = null;
    }
}
